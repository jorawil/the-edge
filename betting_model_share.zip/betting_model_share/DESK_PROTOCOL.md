# Desk protocol — betting_model (one-pager)

**Never place bets. Probability-first only.**

## When to run

- Pre-slate / daily: `python -m betting_model.cli evaluate --props /workspace/betting_model/props_tonight.json`
- After CoS shortlist updates: rewrite props JSON, re-run, feed `out/edges_latest.*` to CoS / ticket build.

## How to use edges

| Signal | Action |
|---|---|
| `positive_edge=True` **and** desk research agrees | Eligible Strong / Med-High lean |
| `positive_edge=True` alone | Research input only — **do not** juice ticket |
| `positive_edge=False` / skipped | Do not elevate on model grounds |
| Unverified odds cite | Live-verify before Strong |

## Ownership

- **NBA Props / Lines & Market**: map shortlist → props JSON; verify prices.
- **Chief of Staff**: merges model edges into slate brief; coordinates desks.
- **Muse**: owns final NFL / WS ticket — model NFL legs are optional inputs only.
- **All desks**: model is a screen, not a green light.

## APIs bots import

```python
from betting_model import implied_probability, calculate_edge, get_nba_player_recent_avg
from betting_model import fetch_live_odds, evaluate_prop
```

## Outputs

- `out/edges_latest.json` — machine
- `out/edges_latest.md` — phone / chat paste

## Odds key (optional)

`export ODDS_API_KEY=...` for `fetch_live_odds`. Missing key → soft fail, no invented prices.
